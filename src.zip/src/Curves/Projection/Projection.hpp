#ifndef PROJECTION_HPP
#define PROJECTION_HPP

#include <unordered_map>
#include <set>
#include "../Curve.hpp"
#include "../utilities.hpp"

class IJ_Cell
{
	private:
		// vector <Traversal *> traversals;
		// set <pair<unsigned int, unsigned int>> diagonal;
		unordered_map<int , vector<vector<pair<unsigned int, unsigned int>>>> traversals;

		void calc_diagon(set <pair<unsigned int, unsigned int>> * diagonal, unsigned int i, unsigned int j, unsigned int dist);
		void calc_traversals(set <pair<unsigned int, unsigned int>> * diagonal, pair<unsigned int, unsigned int> start, pair<unsigned int, unsigned int> end, vector<pair<unsigned int, unsigned int>> traversal);
	public:
		IJ_Cell(unsigned int i, unsigned int j, unsigned int dist = 0);
		~IJ_Cell();
		void insertCurves(Curve * curve1, Curve * curve2, double ** G);
};

double ** createG(int d, int k);
IJ_Cell *** train(vector <Curve*> data, unsigned int M, double **G);


vector <Curve*> struct_initialization(string file);

#endif