#include "Projection.hpp"

#include <chrono>
#include <random>

// Private class IJ_Traversals function
void IJ_Cell::calc_diagon(set <pair<unsigned int, unsigned int>> * diagonal, unsigned int sizeI, unsigned int sizeJ, unsigned int dist)
/* If distance > 1 we add matrix elements with distance = dist from the diagonal */
{
	if (sizeI == 0 || sizeJ == 0)
	{
		return;
	}

	double angle = (double)sizeJ/sizeI;
	double rev_angle = (double)sizeI/sizeJ;
	for (int i = 0; i < sizeI; i++)
	{
		diagonal->insert(make_pair(i, floor(i * angle)));
	}
	for (int j = 0; j < sizeJ; j++)
	{
		diagonal->insert(make_pair(floor(j * rev_angle), j));
	}

	return;
}

void IJ_Cell::calc_traversals(set <pair<unsigned int, unsigned int>> * diagonal, pair<unsigned int, unsigned int> start, pair<unsigned int, unsigned int> end, vector<pair<unsigned int, unsigned int>> traversal)
{
// cout << get<0>(start) << "  " <<  get<1>(start)<< endl;
	if (start == end)
	{
		traversal.push_back(start);

		unordered_map<int , vector<vector<pair<unsigned int, unsigned int>>>>::const_iterator got = this->traversals.find (traversal.size());
		if (got == this->traversals.end())
		{
for (auto i = traversal.begin(); i != traversal.end(); ++i)
    std::cout << get<1>(*i) << ' ' << get<0>(*i) << endl;
cout << "            graefjaweiulfhweliaudhfiwleha" << endl;

			vector<vector<pair<unsigned int, unsigned int>>> to_insert;
			to_insert.push_back(traversal);
			this->traversals.insert(make_pair(traversal.size(), to_insert));
		}
		else
		{
			this->traversals.at(traversal.size()).push_back(traversal);
		}
	}
	else if (diagonal->find(start) != diagonal->end())
	{
		traversal.push_back(start);
		this->calc_traversals(diagonal, make_pair(get<0>(start)+1, get<1>(start)), end, traversal);
		this->calc_traversals(diagonal, make_pair(get<0>(start), get<1>(start)+1), end, traversal);
		this->calc_traversals(diagonal, make_pair(get<0>(start)+1, get<1>(start)+1), end, traversal);
	}

	return;
}

// Class IJ_Traversals
IJ_Cell::IJ_Cell(unsigned int i, unsigned int j, unsigned int dist)
{
	set <pair<unsigned int, unsigned int>> diagonal;
	this->calc_diagon(&diagonal, i ,j ,dist);

if (i == 7 && j == 5)
{
	
cout << "traversal " << i << " " << j << endl;
	vector<pair<unsigned int, unsigned int>> temp;
	this->calc_traversals(&diagonal, make_pair(0,0), make_pair(i-1,j-1), temp);
cout << "end traversal" << endl;
}
	diagonal.clear();
}

IJ_Cell::~IJ_Cell()
{
	this->traversals.clear();
}

void IJ_Cell::insertCurves(Curve * curve1, Curve * curve2, double **G){

	// Create Traversal

	// For each Traversal
	// try {
	// 	this->traversals.push_back(new Traversal(curve1, curve2  traversal vector));
	// }
	// catch (std::bad_alloc& ba)
	// {
	// 	exit(1);
	// }
}

// Functions
double ** createG(int k, int d){

	double ** G;

	int pos = 0;
	try {
		G = new  double *[k];
		for (pos = 0; pos < k; pos++)
		{
			G[pos] = new double[d];
		}
	}
	catch(std::bad_alloc& ba){
		for (int i = 0; i < pos; i++)
		{
			delete [] G[i];
		}
		delete [] G;
		return NULL;
	}

	unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
	default_random_engine generator (seed);
	normal_distribution<double> distribution(0.0,1.0);

	for (int i = 0; i < k; i++)
	{
		for (int j = 0; j < d; j++)
		{
			G[i][j] = distribution(generator);
		}
	}

	return G;
}

IJ_Cell *** train(vector <Curve*> data, unsigned int M, double **G){

	IJ_Cell *** MM_table;
	unsigned int pos1 = 0, pos2 = 0;
	try {
		MM_table = new IJ_Cell ** [M];
		for (pos1 = 0; pos1 < M; pos1++)
		{
			MM_table[pos1] = new IJ_Cell * [pos1+1];
			for (pos2 = 0; pos2 <= pos1; pos2++)
			{
				MM_table[pos1][pos2] = new IJ_Cell(pos1+1, pos2+1);
			}
		}
	}
	catch (std::bad_alloc& ba) {
		for (int i = 0; i < pos1; i++)
		{
			if (i < pos1-1)
			{
				for (int j = 0; j < i; j++)
				{
					delete MM_table[i][j];
				}
			}
			for (int j = 0; j < pos2; j++)
			{
				delete MM_table[i][j];
			}
			delete [] MM_table[i];
		}
		delete [] MM_table;
		return NULL;
	}

	for (int i = 0; i < data.size(); i++)
	{
		int sizeI = data.at(i)->get_size();
		for (int j = 0; j < data.size(); j++)
		{
			int sizeJ = data.at(j)->get_size();
			// MM_table[sizeI-1][sizeJ-1]->insertCurves(data.at(i), data.at(j), G);
			// MM_table[sizeJ][sizeI].insertTraversals(data.at(j), data.at(i));
		}
	}

	return MM_table;
}

vector <Curve*> struct_initialization(string file){

	ifstream data;

	vector <Curve *> data_vector;
	data.open(file);
	
	string line;
	int i = 0;
	if (data.is_open())
	{
		while ( getline (data, line) && line.length() > 0 )
		{
			int pos1, pos2;
			string sub;

			// Find curve ID
			pos2 = line.find("\t");
			string id = line.substr(0, pos2);

			// Find curve size
			line = line.substr(pos2+1);
			pos2 = line.find("\t");
			sub = line.substr(0, pos2);

			if (stoi(sub) > 25)
			{
				continue;
			}

			data_vector.push_back(new Curve(id));

			double x,y;
			while (!line.empty())
			{
				// Find coordinate x
				pos1 = line.find("("); 
				pos2 = line.find(","); 
				sub = line.substr(pos1 + 1, pos2 - pos1 - 1);
				x = stod(sub);

				// Move line
				line = line.substr(pos2 + 2);

				// Find coordinate y
				pos2 = line.find(")");
				sub = line.substr(0, pos2); 
				y = stod(sub);

				// Move line
				line = line.substr(pos2 + 1);

				data_vector.at(i)->add_point(x, y);
			}

			i++;
		}
		data.close();
	}

	return data_vector;

}